const STORAGE_KEY = "settings";

async function loadSettings() {
  const { settings } = await chrome.storage.sync.get([STORAGE_KEY]);
  return settings || { enabled: true, profile: {} };
}

async function saveSettings(settings) {
  await chrome.storage.sync.set({ [STORAGE_KEY]: settings });
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

async function init() {
  const enabledInput = document.getElementById("enabled");
  const fillNowBtn = document.getElementById("fillNow");
  const openOptionsBtn = document.getElementById("openOptions");

  const settings = await loadSettings();
  enabledInput.checked = settings.enabled !== false;

  enabledInput.addEventListener("change", async () => {
    const next = { ...settings, enabled: enabledInput.checked };
    await saveSettings(next);
    setStatus(enabledInput.checked ? "Autofill ON" : "Autofill OFF");
  });

  fillNowBtn.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;

    chrome.tabs.sendMessage(tab.id, { type: "AUTOFILL_NOW" }, (response) => {
      if (chrome.runtime.lastError) {
        setStatus("このページでは実行できません");
        return;
      }

      if (!response?.ok) {
        setStatus("入力に失敗しました");
        return;
      }

      const filled = response.result?.filled || 0;
      setStatus(`${filled}項目を入力`);
    });
  });

  openOptionsBtn.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}

init();
