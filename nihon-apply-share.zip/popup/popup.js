const { storageGet, storageSet, queryTabs, sendMessage, openOptionsPage } =
  globalThis.ExtensionApiCompat || {};

if (!storageGet || !storageSet || !queryTabs || !sendMessage || !openOptionsPage) {
  throw new Error("Extension API compatibility helpers are not available.");
}

const STORAGE_KEY = "settings";

async function loadSettings() {
  const { settings } = await storageGet([STORAGE_KEY]);
  return settings || { enabled: true, profile: {} };
}

async function saveSettings(settings) {
  await storageSet({ [STORAGE_KEY]: settings });
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

async function init() {
  const enabledInput = document.getElementById("enabled");
  const fillNowBtn = document.getElementById("fillNow");
  const openOptionsBtn = document.getElementById("openOptions");

  const [activeTab] = await queryTabs({ active: true, currentWindow: true });
  if (activeTab?.id) {
    try {
      await sendMessage(activeTab.id, { type: "MAGULIFY_SHOW_LAUNCHER" });
    } catch (_err) {
      // Ignore on unsupported pages.
    }
  }

  const settings = await loadSettings();
  enabledInput.checked = settings.enabled !== false;

  enabledInput.addEventListener("change", async () => {
    const next = { ...settings, enabled: enabledInput.checked };
    await saveSettings(next);
    setStatus(enabledInput.checked ? "Autofill ON" : "Autofill OFF");
  });

  fillNowBtn.addEventListener("click", async () => {
    const [tab] = await queryTabs({ active: true, currentWindow: true });
    if (!tab?.id) return;

    try {
      const response = await sendMessage(tab.id, { type: "AUTOFILL_NOW" });
      if (!response?.ok) {
        setStatus("入力に失敗しました");
        return;
      }

      const filled = response.result?.filled || 0;
      setStatus(`${filled}項目を入力`);
    } catch (_err) {
      setStatus("このページでは実行できません");
    }
  });

  openOptionsBtn.addEventListener("click", async () => {
    await openOptionsPage();
  });
}

init();
