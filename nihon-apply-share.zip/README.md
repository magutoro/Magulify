# Nihon Apply Autofill (MVP)

Japanese-focused Chrome extension that autofills job application forms.

## Features

- Autofills common Japanese and English form labels used in recruiting sites.
- Supports names (Kanji/Kana), contact info, address, education, experience, and profile links.
- Supports English name fields (family/given in Western Script).
- Supports preferred name (`希望名 / Preferred Name`) fields.
- If a form asks Furigana in Hiragana, it converts saved Katakana Furigana to Hiragana before filling.
- Runs autofill automatically after page load (and still supports manual trigger).
- Supports gender and password fields.
- Supports native `<select>` dropdowns and common ARIA combobox dropdowns.
- Supports split email fields (`local-part` + `domain`) and split phone/postal multi-input fields.
- Supports split birth date fields (year/month/day dropdown or combobox style).
- Detects hyphen-required phone/postal single-input formats and fills in the expected style.
- Supports education filter UIs (school type, school-name initial, and school location selection).
- Popup actions:
  - Enable/disable autofill
  - Autofill current page
  - Open profile settings
- Keyboard shortcut: `Ctrl+Shift+Y` (`Command+Shift+Y` on macOS)
- Local profile storage using `chrome.storage.sync`

## Load in Chrome

1. Open `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select: `extension/`

## Notes

- This is an MVP. Dynamic multi-step forms and heavy anti-bot flows can require site-specific adapters.
- Add your own matching patterns in `src/content.js` (`NON_NAME_FIELD_PATTERNS`) for better coverage.
