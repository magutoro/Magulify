# Nihon Apply Autofill (MVP)

Japanese-focused WebExtension that autofills job application forms.

## Features

- Autofills common Japanese and English form labels used in recruiting sites.
- Supports names (Kanji/Kana), contact info, address, education, experience, and profile links.
- Supports English name fields (family/given in Western Script).
- Supports preferred name (`希望名 / Preferred Name`) fields.
- If a form asks Furigana in Hiragana, it converts saved Katakana Furigana to Hiragana before filling.
- Runs autofill automatically after page load (and still supports manual trigger).
- Supports gender and password fields.
- Supports native `<select>` dropdowns and common ARIA combobox dropdowns.
- Supports split email fields (`local-part` + `domain`) and split phone/postal multi-input fields.
- Supports split birth date fields (year/month/day dropdown or combobox style).
- Detects hyphen-required phone/postal single-input formats and fills in the expected style.
- Supports education filter UIs (school type, school-name initial, and school location selection).
- Shows an in-page right-side profile panel with one-click copy blocks, launched from a movable `M` side button.
- Popup actions:
  - Enable/disable autofill
  - Autofill current page
  - Open profile settings
- Keyboard shortcut: `Ctrl+Shift+Y` (`Command+Shift+Y` on macOS)
- Local profile storage using WebExtension storage (`sync` when available, `local` fallback for Safari compatibility)

## Load in Chrome

1. Open `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select: `extension/`

## Load in Safari

1. Open Safari and enable **Develop** menu in settings.
2. Choose **Develop > Allow Unsigned Extensions**.
3. Build and run this folder as a Safari Web Extension project from Xcode.
4. Enable the extension in **Safari > Settings > Extensions**.

## Notes

- This is an MVP. Dynamic multi-step forms and heavy anti-bot flows can require site-specific adapters.
- Add your own matching patterns in `src/content.js` (`NON_NAME_FIELD_PATTERNS`) for better coverage.
