const STORAGE_KEY = "settings";

const DEFAULT_PROFILE = {
  lastNameKanji: "",
  firstNameKanji: "",
  lastNameKana: "",
  firstNameKana: "",
  lastNameEnglish: "",
  firstNameEnglish: "",
  preferredName: "",
  email: "",
  phone: "",
  gender: "",
  password: "",
  postalCode: "",
  prefecture: "",
  city: "",
  addressLine1: "",
  addressLine2: "",
  birthDate: "",
  university: "",
  educationType: "",
  universityKanaInitial: "",
  universityPrefecture: "",
  faculty: "",
  graduationYear: "",
  company: "",
  linkedIn: "",
  github: "",
  portfolio: "",
  note: ""
};

async function loadSettings() {
  const { settings } = await chrome.storage.sync.get([STORAGE_KEY]);
  return settings || { enabled: true, profile: { ...DEFAULT_PROFILE } };
}

async function saveSettings(settings) {
  await chrome.storage.sync.set({ [STORAGE_KEY]: settings });
}

function setStatus(message) {
  document.getElementById("status").textContent = message;
}

function fillForm(profile) {
  const form = document.getElementById("profileForm");
  Object.entries(DEFAULT_PROFILE).forEach(([key, fallback]) => {
    const field = form.elements.namedItem(key);
    if (!field) return;
    field.value = profile[key] ?? fallback;
  });
}

function readForm() {
  const form = document.getElementById("profileForm");
  const next = { ...DEFAULT_PROFILE };
  Object.keys(DEFAULT_PROFILE).forEach((key) => {
    const field = form.elements.namedItem(key);
    if (!field) return;
    next[key] = field.value.trim();
  });
  return next;
}

function download(filename, content) {
  const blob = new Blob([content], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function init() {
  const form = document.getElementById("profileForm");
  const resetBtn = document.getElementById("resetBtn");
  const exportBtn = document.getElementById("exportBtn");

  let settings = await loadSettings();
  fillForm(settings.profile || {});

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    settings = { ...settings, profile: readForm() };
    await saveSettings(settings);
    setStatus("保存しました");
  });

  resetBtn.addEventListener("click", async () => {
    settings = { ...settings, profile: { ...DEFAULT_PROFILE } };
    fillForm(settings.profile);
    await saveSettings(settings);
    setStatus("リセットしました");
  });

  exportBtn.addEventListener("click", () => {
    const payload = JSON.stringify(readForm(), null, 2);
    download("nihon-apply-profile.json", payload);
    setStatus("JSONを出力しました");
  });
}

init();
