const STORAGE_KEY = "settings";

const DEFAULT_PROFILE = {
  lastNameKanji: "",
  firstNameKanji: "",
  lastNameKana: "",
  firstNameKana: "",
  preferredName: "",
  email: "",
  phone: "",
  gender: "",
  password: "",
  postalCode: "",
  prefecture: "",
  city: "",
  addressLine1: "",
  addressLine2: "",
  birthDate: "",
  university: "",
  faculty: "",
  graduationYear: "",
  company: "",
  linkedIn: "",
  github: "",
  portfolio: "",
  note: ""
};

const PASSWORD_RULE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;

async function loadSettings() {
  const { settings } = await chrome.storage.sync.get([STORAGE_KEY]);
  return settings || { enabled: true, profile: { ...DEFAULT_PROFILE } };
}

async function saveSettings(settings) {
  await chrome.storage.sync.set({ [STORAGE_KEY]: settings });
}

function setStatus(message) {
  document.getElementById("status").textContent = message;
}

function fillForm(profile) {
  const form = document.getElementById("profileForm");
  Object.entries(DEFAULT_PROFILE).forEach(([key, fallback]) => {
    const field = form.elements.namedItem(key);
    if (!field) return;
    field.value = profile[key] ?? fallback;
  });
}

function readForm() {
  const form = document.getElementById("profileForm");
  const next = { ...DEFAULT_PROFILE };
  Object.keys(DEFAULT_PROFILE).forEach((key) => {
    const field = form.elements.namedItem(key);
    if (!field) return;
    next[key] = field.value.trim();
  });
  return next;
}

function validateProfile(profile) {
  if (!PASSWORD_RULE.test(profile.password || "")) {
    return "パスワードは8文字以上で、英大文字/小文字/数字/記号を含めてください";
  }
  return "";
}

function download(filename, content) {
  const blob = new Blob([content], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

async function init() {
  const form = document.getElementById("profileForm");
  const resetBtn = document.getElementById("resetBtn");
  const exportBtn = document.getElementById("exportBtn");

  let settings = await loadSettings();
  fillForm(settings.profile || {});

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const nextProfile = readForm();
    const validationError = validateProfile(nextProfile);
    if (validationError) {
      setStatus(validationError);
      const passwordField = form.elements.namedItem("password");
      if (passwordField) passwordField.focus();
      return;
    }

    settings = { ...settings, profile: nextProfile };
    await saveSettings(settings);
    setStatus("保存しました");
  });

  resetBtn.addEventListener("click", async () => {
    settings = { ...settings, profile: { ...DEFAULT_PROFILE } };
    fillForm(settings.profile);
    await saveSettings(settings);
    setStatus("リセットしました");
  });

  exportBtn.addEventListener("click", () => {
    const payload = JSON.stringify(readForm(), null, 2);
    download("nihon-apply-profile.json", payload);
    setStatus("JSONを出力しました");
  });
}

init();
