const STORAGE_KEY = "settings";

const NON_NAME_FIELD_PATTERNS = {
  email: [/mail/, /e-?mail/, /メール/],
  phone: [/tel/, /phone/, /電話/],
  postalCode: [/postal/, /zip/, /郵便/],
  prefecture: [/prefecture/, /都道府県/],
  city: [/city/, /市区町村/],
  addressLine1: [/address/, /住所/, /丁目|番地/],
  addressLine2: [/building/, /マンション/, /建物/, /号室/],
  birthDate: [/birth/, /birthday/, /生年月日/],
  gender: [/gender/, /sex/, /性別/],
  password: [/password/, /passcode/, /パスワード/, /暗証/],
  university: [/university/, /college/, /大学/],
  faculty: [/faculty/, /学部/, /専攻/, /major/],
  graduationYear: [/graduation/, /卒業/, /year/],
  company: [/company/, /current.?employer/, /勤務先/, /会社/],
  linkedIn: [/linkedin/],
  github: [/github/],
  portfolio: [/portfolio/, /website/, /url/, /ブログ/],
  note: [/self.?pr/, /自己pr/, /志望動機/, /message/, /備考/, /cover.?letter/]
};

const KANA_FIELD_KEYS = new Set(["lastNameKana", "firstNameKana"]);
const KANA_SCRIPT_KEYS = new Set(["kana", "hiragana", "katakana"]);
const AUTO_RUN_OBSERVE_MS = 15000;
const AUTO_RUN_DEBOUNCE_MS = 600;

const GENDER_VALUE_ALIASES = {
  male: ["male", "man", "m", "男性", "男", "男性（男）", "男性（man）"],
  female: ["female", "woman", "f", "女性", "女", "女性（女）", "女性（woman）"],
  non_binary: ["non binary", "non-binary", "x", "ノンバイナリー", "その他"],
  prefer_not_to_say: ["prefer not to say", "none", "無回答", "回答しない", "選択しない"],
  other: ["other", "others", "その他", "該当なし"]
};

function normalize(text) {
  return (text || "")
    .toString()
    .toLowerCase()
    .replace(/[\s\-_:/\\|()\[\]{}]+/g, " ")
    .trim();
}

function isVisible(el) {
  if (!(el instanceof HTMLElement)) return false;
  const style = getComputedStyle(el);
  if (style.visibility === "hidden" || style.display === "none") return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function getTextMeta(el) {
  const parts = [
    el.id,
    el.name,
    el.placeholder,
    el.autocomplete,
    el.getAttribute("aria-label"),
    el.getAttribute("data-testid"),
    el.getAttribute("data-qa"),
    el.className
  ];

  if (el.labels?.length) {
    for (const lbl of el.labels) parts.push(lbl.textContent);
  }

  const labelledBy = el.getAttribute("aria-labelledby");
  if (labelledBy) {
    labelledBy.split(/\s+/).forEach((id) => {
      const node = document.getElementById(id);
      if (node?.textContent) parts.push(node.textContent);
    });
  }

  const row = el.closest("fieldset, div, section, tr, li");
  if (row) {
    const labelLike = row.querySelector("label, legend, th, dt, .label, .title");
    if (labelLike?.textContent) parts.push(labelLike.textContent);
  }

  return normalize(parts.filter(Boolean).join(" "));
}

function detectNamePart(meta) {
  if (!meta) return null;

  const hasNameContext = /(name|family|given|first|last|surname|full.?name|氏名|姓名|お名前|姓|名)/.test(meta);
  if (!hasNameContext) return null;

  if (/(company|organization|school|faculty|大学|会社|企業|団体|学校|学部)/.test(meta) && !/(姓|名|first|last|given|family|surname)/.test(meta)) {
    return null;
  }

  if (/(family.?name|last.?name|surname|姓|名字)/.test(meta)) return "last";
  if (/(given.?name|first.?name|名)/.test(meta)) return "first";
  return null;
}

function detectNameScriptHint(meta) {
  if (!meta) return "unknown";
  if (/(western.?script|roman|latin|alphabet|英字|ローマ字)/.test(meta)) return "roman";
  if (/(hiragana|ひらがな)/.test(meta)) return "hiragana";
  if (/(katakana|カタカナ|全角.?カナ)/.test(meta)) return "katakana";
  if (/(furigana|kana|かな|カナ|ふりがな|フリガナ|phonetic)/.test(meta)) return "kana";
  if (/(kanji|漢字)/.test(meta)) return "kanji";
  return "unknown";
}

function chooseUnknownScript(partCandidates) {
  const hasExplicitKanji = partCandidates.some((x) => x.scriptHint === "kanji");
  const hasExplicitKana = partCandidates.some((x) => KANA_SCRIPT_KEYS.has(x.scriptHint));

  for (const candidate of partCandidates) {
    if (candidate.scriptHint !== "unknown") continue;

    if (hasExplicitKanji && !hasExplicitKana) {
      candidate.scriptHint = "kana";
      continue;
    }

    if (hasExplicitKana && !hasExplicitKanji) {
      candidate.scriptHint = "kanji";
      continue;
    }

    candidate.scriptHint = "kanji";
  }
}

function mapNameCandidate(candidate) {
  if (!candidate.namePart || !candidate.scriptHint) return;

  if (candidate.scriptHint === "roman") {
    candidate.field = null;
    return;
  }

  if (candidate.namePart === "last") {
    if (candidate.scriptHint === "kanji") {
      candidate.field = "lastNameKanji";
      return;
    }

    if (candidate.scriptHint === "hiragana") {
      candidate.field = "lastNameKana";
      candidate.kanaTarget = "hiragana";
      return;
    }

    if (candidate.scriptHint === "katakana") {
      candidate.field = "lastNameKana";
      candidate.kanaTarget = "katakana";
      return;
    }

    candidate.field = "lastNameKana";
    return;
  }

  if (candidate.namePart === "first") {
    if (candidate.scriptHint === "kanji") {
      candidate.field = "firstNameKanji";
      return;
    }

    if (candidate.scriptHint === "hiragana") {
      candidate.field = "firstNameKana";
      candidate.kanaTarget = "hiragana";
      return;
    }

    if (candidate.scriptHint === "katakana") {
      candidate.field = "firstNameKana";
      candidate.kanaTarget = "katakana";
      return;
    }

    candidate.field = "firstNameKana";
  }
}

function assignNameFields(candidates) {
  const grouped = { last: [], first: [] };

  for (const candidate of candidates) {
    const part = detectNamePart(candidate.meta);
    if (!part) continue;

    candidate.namePart = part;
    candidate.scriptHint = detectNameScriptHint(candidate.meta);
    grouped[part].push(candidate);
  }

  chooseUnknownScript(grouped.last);
  chooseUnknownScript(grouped.first);

  for (const candidate of grouped.last) mapNameCandidate(candidate);
  for (const candidate of grouped.first) mapNameCandidate(candidate);
}

function matchNonNameField(meta, type) {
  if (type === "email") return "email";
  if (type === "tel") return "phone";
  if (type === "url") return "portfolio";
  if (type === "password") return "password";

  for (const [field, patterns] of Object.entries(NON_NAME_FIELD_PATTERNS)) {
    if (patterns.some((pattern) => pattern.test(meta))) {
      return field;
    }
  }

  return null;
}

function katakanaToHiragana(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u30a1-\u30f6]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0x60));
}

function hiraganaToKatakana(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u3041-\u3096]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) + 0x60));
}

function resolveAutofillValue(field, rawValue, kanaTarget) {
  if (rawValue == null || rawValue === "") return rawValue;
  if (!KANA_FIELD_KEYS.has(field)) return rawValue;

  if (kanaTarget === "hiragana") return katakanaToHiragana(rawValue);
  if (kanaTarget === "katakana") return hiraganaToKatakana(rawValue);
  return rawValue;
}

function splitPostal(value) {
  const digits = (value || "").replace(/\D/g, "");
  return [digits.slice(0, 3), digits.slice(3, 7)];
}

function splitPhone(value) {
  const digits = (value || "").replace(/\D/g, "");
  if (digits.length < 10) return [digits, "", ""];
  return [digits.slice(0, 3), digits.slice(3, 7), digits.slice(7, 11)];
}

function expandCandidateValues(field, value) {
  if (value == null || value === "") return [];

  if (field !== "gender") return [String(value)];

  const aliasValues = GENDER_VALUE_ALIASES[value] || [];
  return [String(value), ...aliasValues];
}

function chooseMatchingOption(options, candidates) {
  if (!options.length || !candidates.length) return null;

  const normalizedCandidates = candidates.map((x) => normalize(x)).filter(Boolean);

  for (const option of options) {
    const text = normalize(option.textContent || option.label || "");
    const val = normalize(option.value || "");
    if (normalizedCandidates.some((target) => target === text || target === val)) {
      return option;
    }
  }

  for (const option of options) {
    const text = normalize(option.textContent || option.label || "");
    const val = normalize(option.value || "");
    if (normalizedCandidates.some((target) => text.includes(target) || val.includes(target))) {
      return option;
    }
  }

  return null;
}

function clickLikeUser(el) {
  ["pointerdown", "mousedown", "mouseup", "click"].forEach((eventName) => {
    el.dispatchEvent(new MouseEvent(eventName, { bubbles: true, cancelable: true, view: window }));
  });
}

function selectFromCustomCombobox(el, field, value) {
  const candidates = expandCandidateValues(field, value);
  if (!candidates.length) return false;

  clickLikeUser(el);

  const ariaControls = el.getAttribute("aria-controls");
  const scoped = ariaControls ? document.getElementById(ariaControls) : null;
  const optionSelector = "[role='option'], [data-value], li";

  const nodes = (scoped || document)
    ? Array.from((scoped || document).querySelectorAll(optionSelector)).filter((node) => isVisible(node) && normalize(node.textContent).length > 0)
    : [];

  const matched = chooseMatchingOption(nodes, candidates);
  if (!matched) return false;

  clickLikeUser(matched);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function isCustomCombobox(el) {
  return el.getAttribute("role") === "combobox" && el.tagName !== "SELECT";
}

function hasExistingValue(el) {
  if (el.tagName === "SELECT") return Boolean(el.value);
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return el.value.trim() !== "";
  const text = normalize(el.textContent);
  return text !== "";
}

function setFieldValue(el, field, value, options = {}) {
  const { overwrite = true } = options;
  if (value == null || value === "") return false;
  if (!overwrite && hasExistingValue(el)) return false;

  if (el.tagName === "SELECT") {
    const option = chooseMatchingOption(Array.from(el.options), expandCandidateValues(field, value));
    if (!option) return false;
    el.value = option.value;
  } else if (isCustomCombobox(el)) {
    return selectFromCustomCombobox(el, field, value);
  } else if (el.type === "checkbox" || el.type === "radio") {
    return false;
  } else {
    el.focus();
    el.value = String(value);
  }

  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function isFillable(el) {
  if (!(el instanceof HTMLElement)) return false;
  if (!isVisible(el)) return false;
  if (el.matches("[disabled], [readonly], [type='hidden']")) return false;
  if (el.getAttribute("aria-hidden") === "true") return false;
  return el.matches("input, textarea, select, [role='combobox']");
}

function fillSplitFields(candidates, profile, overwrite) {
  const postalFields = candidates.filter((x) => x.meta.includes("郵便") || x.meta.includes("postal") || x.meta.includes("zip"));
  if (postalFields.length >= 2) {
    const [a, b] = splitPostal(profile.postalCode);
    setFieldValue(postalFields[0].el, "postalCode", a, { overwrite });
    setFieldValue(postalFields[1].el, "postalCode", b, { overwrite });
  }

  const phoneFields = candidates.filter((x) => x.meta.includes("電話") || x.meta.includes("phone") || x.meta.includes("tel"));
  if (phoneFields.length >= 3) {
    const [a, b, c] = splitPhone(profile.phone);
    setFieldValue(phoneFields[0].el, "phone", a, { overwrite });
    setFieldValue(phoneFields[1].el, "phone", b, { overwrite });
    setFieldValue(phoneFields[2].el, "phone", c, { overwrite });
  }
}

async function getSettings() {
  const stored = await chrome.storage.sync.get([STORAGE_KEY]);
  return stored[STORAGE_KEY] || { enabled: true, profile: {} };
}

async function autofill(options = {}) {
  const { overwrite = true } = options;
  const settings = await getSettings();
  if (!settings.enabled) {
    return { filled: 0, reason: "disabled" };
  }

  const profile = settings.profile || {};
  const inputs = Array.from(document.querySelectorAll("input, textarea, select, [role='combobox']")).filter(isFillable);

  const candidates = inputs.map((el) => {
    const meta = getTextMeta(el);
    return { el, meta, field: null, kanaTarget: null, namePart: null, scriptHint: null };
  });

  assignNameFields(candidates);

  for (const candidate of candidates) {
    if (candidate.field !== null && candidate.field !== undefined) continue;
    candidate.field = matchNonNameField(candidate.meta, (candidate.el.type || "").toLowerCase());
  }

  fillSplitFields(candidates, profile, overwrite);

  let filled = 0;
  for (const { el, field, kanaTarget } of candidates) {
    if (!field) continue;
    const value = resolveAutofillValue(field, profile[field], kanaTarget);
    if (setFieldValue(el, field, value, { overwrite })) filled += 1;
  }

  return { filled };
}

function debounce(fn, waitMs) {
  let timeoutId = null;
  return (...args) => {
    window.clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => fn(...args), waitMs);
  };
}

function startAutoRun() {
  const trigger = debounce(() => {
    autofill({ overwrite: false }).catch(() => {});
  }, AUTO_RUN_DEBOUNCE_MS);

  trigger();

  const observer = new MutationObserver(() => trigger());
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.setTimeout(() => observer.disconnect(), AUTO_RUN_OBSERVE_MS);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startAutoRun, { once: true });
} else {
  startAutoRun();
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "AUTOFILL_NOW") return;

  autofill({ overwrite: true })
    .then((result) => sendResponse({ ok: true, result }))
    .catch((err) => sendResponse({ ok: false, error: String(err) }));

  return true;
});
