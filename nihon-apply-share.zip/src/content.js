const { extensionApi, storageGet, storageSet, openOptionsPage } = globalThis.ExtensionApiCompat || {};

if (!extensionApi || !storageGet || !storageSet || !openOptionsPage) {
  throw new Error("Extension API compatibility helpers are not available.");
}

const STORAGE_KEY = "settings";

const NON_NAME_FIELD_PATTERNS = {
  email: [/mail/, /e-?mail/, /メール/],
  phone: [/tel/, /phone/, /電話/],
  postalCode: [/postal/, /post.?code/, /zip/, /〒/, /郵便/, /郵便番号/],
  prefecture: [/prefecture/, /都道府県/],
  city: [/city/, /市区町村/],
  addressLine1: [/address/, /住所/, /丁目|番地/],
  addressLine2: [/building/, /マンション/, /建物/, /号室/],
  birthDate: [/birth/, /birthday/, /生年月日/],
  preferredName: [/preferred.?name/, /preffered.?name/, /希望名/, /通称/, /ニックネーム/],
  gender: [/gender/, /sex/, /性別/],
  password: [/password/, /passcode/, /パスワード/, /暗証/],
  educationType: [/学校区分/, /学歴区分/, /school.?type/, /education.?type/],
  universityKanaInitial: [/学校名頭文字/, /頭文字/, /name.?initial/],
  universityPrefecture: [/学校所在地/, /大学所在地/, /所在地.*都道府県/, /所在地.*検索対象/, /university.*prefecture/],
  university: [/university/, /college/, /大学名/, /出身校/, /学校名/],
  faculty: [/faculty/, /学部/, /専攻/, /major/],
  graduationYear: [/graduation/, /卒業/, /year/],
  company: [/company/, /current.?employer/, /勤務先/, /会社/],
  linkedIn: [/linkedin/],
  github: [/github/],
  portfolio: [/portfolio/, /website/, /url/, /ブログ/],
  note: [/self.?pr/, /自己pr/, /志望動機/, /message/, /備考/, /cover.?letter/]
};

const KANA_FIELD_KEYS = new Set(["lastNameKana", "firstNameKana"]);
const KANA_SCRIPT_KEYS = new Set(["kana", "hiragana", "katakana"]);
const AUTO_RUN_OBSERVE_MS = 15000;
const AUTO_RUN_DEBOUNCE_MS = 600;
const OVERLAY_HOST_ID = "magulify-inpage-overlay";
const OVERLAY_DOMAIN_STATE_KEY = "overlayDomainState";

const GENDER_VALUE_ALIASES = {
  male: ["male", "man", "m", "男性", "男", "男性（男）", "男性（man）"],
  female: ["female", "woman", "f", "女性", "女", "女性（女）", "女性（woman）"],
  non_binary: ["non binary", "non-binary", "x", "ノンバイナリー", "その他"],
  prefer_not_to_say: ["prefer not to say", "none", "無回答", "回答しない", "選択しない"],
  other: ["other", "others", "その他", "該当なし"]
};

const EDUCATION_TYPE_ALIASES = {
  university: ["university", "大学"],
  graduate_master: ["graduate school master", "master", "修士", "大学院（修士）", "大学院(修士)"],
  graduate_doctor: ["graduate school doctor", "doctor", "phd", "博士", "大学院（博士）", "大学院(博士)"],
  junior_college: ["junior college", "短期大学", "短大"],
  technical_college: ["technical college", "高等専門学校", "高専"],
  vocational: ["vocational school", "専門学校"],
  high_school: ["high school", "高校", "高等学校"],
  foreign_university_jp: ["foreign university japan", "外国大学日本校"],
  foreign_university: ["foreign university", "外国大学"]
};

const EDUCATION_TYPE_LABELS = {
  university: "大学",
  graduate_master: "大学院(修士)",
  graduate_doctor: "大学院(博士)",
  junior_college: "短期大学",
  technical_college: "高等専門学校",
  vocational: "専門学校",
  high_school: "高等学校",
  foreign_university_jp: "外国大学日本校",
  foreign_university: "外国大学"
};

let overlayRefs = null;
let storageListenerBound = false;
let launcherTopPx = 180;

function normalize(text) {
  return (text || "")
    .toString()
    .toLowerCase()
    .replace(/[\s\-_:/\\|()\[\]{}]+/g, " ")
    .trim();
}

function toHalfWidth(text) {
  return String(text || "")
    .normalize("NFKC")
    .replace(/[\uFF01-\uFF5E]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/\u3000/g, " ");
}

function extractDigits(text) {
  return toHalfWidth(text).replace(/\D/g, "");
}

function splitEmailAddress(email) {
  const normalized = toHalfWidth(email).trim();
  const atIndex = normalized.indexOf("@");
  if (atIndex < 0) return [normalized, ""];
  return [normalized.slice(0, atIndex), normalized.slice(atIndex + 1)];
}

function isVisible(el) {
  if (!(el instanceof HTMLElement)) return false;
  const style = getComputedStyle(el);
  if (style.visibility === "hidden" || style.display === "none") return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function getTextMeta(el) {
  const parts = [
    el.id,
    el.name,
    el.placeholder,
    el.autocomplete,
    el.getAttribute("aria-label"),
    el.getAttribute("data-testid"),
    el.getAttribute("data-qa"),
    el.className
  ];

  if (el.labels?.length) {
    for (const lbl of el.labels) parts.push(lbl.textContent);
  }

  const labelledBy = el.getAttribute("aria-labelledby");
  if (labelledBy) {
    labelledBy.split(/\s+/).forEach((id) => {
      const node = document.getElementById(id);
      if (node?.textContent) parts.push(node.textContent);
    });
  }

  const row = el.closest("fieldset, div, section, tr, li");
  if (row) {
    const labelLike = row.querySelector("label, legend, th, dt, .label, .title");
    if (labelLike?.textContent) parts.push(labelLike.textContent);
  }

  return normalize(parts.filter(Boolean).join(" "));
}

function getRawHintText(el) {
  const parts = [
    el.id,
    el.name,
    el.placeholder,
    el.getAttribute("aria-label"),
    el.getAttribute("title"),
    el.getAttribute("pattern")
  ];

  if (el.labels?.length) {
    for (const lbl of el.labels) parts.push(lbl.textContent);
  }

  const labelledBy = el.getAttribute("aria-labelledby");
  if (labelledBy) {
    labelledBy.split(/\s+/).forEach((id) => {
      const node = document.getElementById(id);
      if (node?.textContent) parts.push(node.textContent);
    });
  }

  return parts.filter(Boolean).join(" ");
}

function detectNamePart(meta) {
  if (!meta) return null;

  if (
    /(建物名|会社名|学校名|大学名|病院名|商品名|地名|町名|部署名|ユーザー名|サイト名|件名|署名|宛名|希望名|通称|ニックネーム|建物|部屋|号室)/.test(
      meta
    ) &&
    !/(family.?name|last.?name|given.?name|first.?name|surname|姓名|氏名)/.test(meta)
  ) {
    return null;
  }

  const hasStandaloneSei = /(?:^|\s)姓(?:$|\s|[（(])/u.test(meta) || /(?:^|\s)名字(?:$|\s|[（(])/u.test(meta);
  const hasStandaloneMei = /(?:^|\s)名(?:$|\s|[（(])/u.test(meta);
  const hasNameContext = /(name|family|given|first|last|surname|full.?name|氏名|姓名|お名前|姓|名)/.test(meta);
  if (!hasNameContext) return null;

  if (/(company|organization|school|faculty|大学|会社|企業|団体|学校|学部)/.test(meta) && !/(姓|名|first|last|given|family|surname)/.test(meta)) {
    return null;
  }

  if (/(family.?name|last.?name|surname)/.test(meta) || hasStandaloneSei) return "last";
  if (/(given.?name|first.?name)/.test(meta) || hasStandaloneMei) return "first";
  return null;
}

function detectNameScriptHint(meta) {
  if (!meta) return "unknown";
  if (/(western.?script|roman|latin|alphabet|english|英字|英語|ローマ字)/.test(meta)) return "roman";
  if (/(hiragana|ひらがな)/.test(meta)) return "hiragana";
  if (/(katakana|カタカナ|全角.?カナ)/.test(meta)) return "katakana";
  if (/(furigana|kana|かな|カナ|ふりがな|フリガナ|phonetic)/.test(meta)) return "kana";
  if (/(kanji|漢字)/.test(meta)) return "kanji";
  return "unknown";
}

function chooseUnknownScript(partCandidates) {
  const hasExplicitKanji = partCandidates.some((x) => x.scriptHint === "kanji");
  const hasExplicitKana = partCandidates.some((x) => KANA_SCRIPT_KEYS.has(x.scriptHint));

  for (const candidate of partCandidates) {
    if (candidate.scriptHint !== "unknown") continue;

    if (hasExplicitKanji && !hasExplicitKana) {
      candidate.scriptHint = "kana";
      continue;
    }

    if (hasExplicitKana && !hasExplicitKanji) {
      candidate.scriptHint = "kanji";
      continue;
    }

    candidate.scriptHint = "kanji";
  }
}

function mapNameCandidate(candidate) {
  if (!candidate.namePart || !candidate.scriptHint) return;

  if (candidate.scriptHint === "roman") {
    candidate.field = candidate.namePart === "last" ? "lastNameEnglish" : "firstNameEnglish";
    return;
  }

  if (candidate.namePart === "last") {
    if (candidate.scriptHint === "kanji") {
      candidate.field = "lastNameKanji";
      return;
    }

    if (candidate.scriptHint === "hiragana") {
      candidate.field = "lastNameKana";
      candidate.kanaTarget = "hiragana";
      return;
    }

    if (candidate.scriptHint === "katakana") {
      candidate.field = "lastNameKana";
      candidate.kanaTarget = "katakana";
      return;
    }

    candidate.field = "lastNameKana";
    return;
  }

  if (candidate.namePart === "first") {
    if (candidate.scriptHint === "kanji") {
      candidate.field = "firstNameKanji";
      return;
    }

    if (candidate.scriptHint === "hiragana") {
      candidate.field = "firstNameKana";
      candidate.kanaTarget = "hiragana";
      return;
    }

    if (candidate.scriptHint === "katakana") {
      candidate.field = "firstNameKana";
      candidate.kanaTarget = "katakana";
      return;
    }

    candidate.field = "firstNameKana";
  }
}

function assignNameFields(candidates) {
  const grouped = { last: [], first: [] };

  for (const candidate of candidates) {
    const part = detectNamePart(candidate.meta);
    if (!part) continue;

    candidate.namePart = part;
    candidate.scriptHint = detectNameScriptHint(candidate.meta);
    grouped[part].push(candidate);
  }

  chooseUnknownScript(grouped.last);
  chooseUnknownScript(grouped.first);

  for (const candidate of grouped.last) mapNameCandidate(candidate);
  for (const candidate of grouped.first) mapNameCandidate(candidate);
}

function matchNonNameField(meta, type) {
  if (type === "email") return "email";
  if (type === "tel") return "phone";
  if (type === "url") return "portfolio";
  if (type === "password") return "password";

  for (const [field, patterns] of Object.entries(NON_NAME_FIELD_PATTERNS)) {
    if (patterns.some((pattern) => pattern.test(meta))) {
      return field;
    }
  }

  return null;
}

function katakanaToHiragana(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u30a1-\u30f6]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0x60));
}

function hiraganaToKatakana(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u3041-\u3096]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) + 0x60));
}

function splitPostalDigits(value) {
  const digits = extractDigits(value);
  return [digits.slice(0, 3), digits.slice(3, 7)];
}

function getDefaultPhoneLengths(digits) {
  if (digits.length === 11) return [3, 4, 4];
  if (digits.length === 10 && /^(03|06)/.test(digits)) return [2, 4, 4];
  if (digits.length === 10) return [3, 3, 4];
  if (digits.length === 9) return [2, 3, 4];
  return [3, 4, 4];
}

function splitDigitsByLengths(digits, partCount, explicitLengths = []) {
  const parts = [];
  let cursor = 0;

  for (let i = 0; i < partCount; i += 1) {
    if (i === partCount - 1) {
      parts.push(digits.slice(cursor));
      break;
    }

    let len = Number(explicitLengths[i]);
    if (!Number.isFinite(len) || len <= 0) {
      const remainingParts = partCount - i;
      len = Math.max(1, Math.floor((digits.length - cursor) / remainingParts));
    }

    parts.push(digits.slice(cursor, cursor + len));
    cursor += len;
  }

  return parts;
}

function splitPhoneDigits(value, partCount, explicitLengths = []) {
  const digits = extractDigits(value);
  if (!digits) return Array(partCount).fill("");
  if (partCount <= 1) return [digits];

  const hasExplicit = explicitLengths.some((x) => Number.isFinite(Number(x)) && Number(x) > 0);
  const defaultLengths = getDefaultPhoneLengths(digits);
  const lengths = hasExplicit ? explicitLengths : defaultLengths;

  return splitDigitsByLengths(digits, partCount, lengths);
}

function formatPhoneForSingleField(value) {
  const digits = extractDigits(value);
  if (digits.length <= 4) return digits;
  return splitPhoneDigits(digits, 3).filter(Boolean).join("-");
}

function formatPostalForSingleField(value) {
  const [a, b] = splitPostalDigits(value);
  return b ? `${a}-${b}` : a;
}

function parseBirthDate(value) {
  const normalized = toHalfWidth(value).trim();
  const matched = normalized.match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/) || normalized.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (!matched) return null;

  const year = matched[1];
  const monthNum = Number(matched[2]);
  const dayNum = Number(matched[3]);
  if (!Number.isFinite(monthNum) || !Number.isFinite(dayNum)) return null;

  return {
    year,
    month: String(monthNum).padStart(2, "0"),
    monthRaw: String(monthNum),
    day: String(dayNum).padStart(2, "0"),
    dayRaw: String(dayNum)
  };
}

function detectBirthPartHint(candidate) {
  const hint = `${candidate.rawHint || ""} ${candidate.meta || ""}`;
  if (/(year|年|yyyy|yy|birth.?year)/i.test(hint)) return "year";
  if (/(month|月|mm|birth.?month)/i.test(hint)) return "month";
  if (/(day|日|dd|birth.?day)/i.test(hint)) return "day";
  return "";
}

function birthPartValues(part, parsed) {
  if (!parsed) return [];
  if (part === "year") return [parsed.year];
  if (part === "month") return [parsed.month, parsed.monthRaw];
  if (part === "day") return [parsed.day, parsed.dayRaw];
  return [];
}

function getExplicitSegmentLength(el) {
  const maxLen = Number(el.maxLength);
  if (Number.isFinite(maxLen) && maxLen > 0 && maxLen <= 8) return maxLen;

  const pattern = el.getAttribute("pattern") || "";
  const matched = pattern.match(/\{(\d+)\}/);
  if (matched) {
    const len = Number(matched[1]);
    if (Number.isFinite(len) && len > 0 && len <= 8) return len;
  }

  return 0;
}

function shouldHyphenatePhone(candidate) {
  const hint = `${candidate.rawHint || ""} ${candidate.meta || ""}`;
  if (/ハイフン不要|ハイフンなし|記号なし|without hyphen/i.test(hint)) return false;
  if (/ハイフン|半角記号|[-－ー]\d{2,4}[-－ー]\d{2,4}/.test(hint)) return true;
  const pattern = candidate.el.getAttribute("pattern") || "";
  return pattern.includes("-");
}

function shouldHyphenatePostal(candidate) {
  const hint = `${candidate.rawHint || ""} ${candidate.meta || ""}`;
  if (/ハイフン不要|ハイフンなし|記号なし|without hyphen/i.test(hint)) return false;
  if (/〒|郵便番号|ハイフン|[-－ー]\d{4}/.test(hint)) return true;
  const pattern = candidate.el.getAttribute("pattern") || "";
  return pattern.includes("-");
}

function resolveAutofillValue(candidate, profile) {
  const { field, kanaTarget } = candidate;
  const rawValue = profile[field];
  if (rawValue == null || rawValue === "") return rawValue;

  if (field === "postalCode") {
    return shouldHyphenatePostal(candidate) ? formatPostalForSingleField(rawValue) : extractDigits(rawValue);
  }

  if (field === "phone") {
    return shouldHyphenatePhone(candidate) ? formatPhoneForSingleField(rawValue) : extractDigits(rawValue);
  }

  if (!KANA_FIELD_KEYS.has(field)) return rawValue;

  if (kanaTarget === "hiragana") return katakanaToHiragana(rawValue);
  if (kanaTarget === "katakana") return hiraganaToKatakana(rawValue);
  return rawValue;
}

function expandCandidateValues(field, value) {
  if (value == null || value === "") return [];

  if (field === "educationType") {
    const aliases = EDUCATION_TYPE_ALIASES[value] || [];
    return Array.from(new Set([String(value), ...aliases].map((x) => toHalfWidth(x).trim()).filter(Boolean)));
  }

  if (field === "universityKanaInitial") {
    const base = toHalfWidth(String(value)).trim();
    if (!base) return [];
    return Array.from(new Set([base, katakanaToHiragana(base), hiraganaToKatakana(base)]));
  }

  if (field === "birthDate") {
    const normalized = toHalfWidth(String(value)).trim();
    const numeric = String(Number(normalized));
    const values = [normalized];
    if (Number.isFinite(Number(normalized))) values.push(numeric);
    return Array.from(new Set(values.filter(Boolean)));
  }

  if (field !== "gender") return [String(value)];

  const aliasValues = GENDER_VALUE_ALIASES[value] || [];
  return [String(value), ...aliasValues];
}

function getInputLabelText(input) {
  const parts = [input.value, input.getAttribute("aria-label"), input.id, input.name];
  if (input.labels?.length) {
    for (const label of input.labels) parts.push(label.textContent);
  }
  const wrapper = input.closest("label");
  if (wrapper?.textContent) parts.push(wrapper.textContent);
  return normalize(parts.filter(Boolean).join(" "));
}

function setRadioValue(el, field, value, options = {}) {
  const { overwrite = true } = options;
  if (!overwrite && el.checked) return false;

  const targetCandidates = expandCandidateValues(field, value).map((x) => normalize(x)).filter(Boolean);
  if (!targetCandidates.length) return false;

  const escapedName = typeof CSS !== "undefined" && CSS.escape ? CSS.escape(el.name || "") : el.name || "";
  let radios = [];
  if (el.name) {
    radios = Array.from(document.querySelectorAll(`input[type="radio"][name="${escapedName}"]`));
  } else {
    radios = [el];
  }

  radios = radios.filter((radio) => !radio.disabled);
  if (!radios.length) return false;

  const exact = radios.find((radio) => {
    const meta = getInputLabelText(radio);
    const val = normalize(radio.value);
    return targetCandidates.some((target) => target === val || target === meta);
  });

  const fuzzy = exact
    ? exact
    : radios.find((radio) => {
        const meta = getInputLabelText(radio);
        const val = normalize(radio.value);
        return targetCandidates.some((target) => meta.includes(target) || (val && (val.includes(target) || target.includes(val))));
      });

  const matched = fuzzy;
  if (!matched) return false;

  clickLikeUser(matched);
  matched.checked = true;
  matched.dispatchEvent(new Event("input", { bubbles: true }));
  matched.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function chooseMatchingOption(options, candidates) {
  if (!options.length || !candidates.length) return null;

  const normalizedCandidates = candidates.map((x) => normalize(x)).filter(Boolean);

  for (const option of options) {
    const text = normalize(option.textContent || option.label || "");
    const val = normalize(option.value || "");
    if (normalizedCandidates.some((target) => target === text || target === val)) {
      return option;
    }
  }

  for (const option of options) {
    const text = normalize(option.textContent || option.label || "");
    const val = normalize(option.value || "");
    if (normalizedCandidates.some((target) => text.includes(target) || val.includes(target))) {
      return option;
    }
  }

  return null;
}

function clickLikeUser(el) {
  ["pointerdown", "mousedown", "mouseup", "click"].forEach((eventName) => {
    el.dispatchEvent(new MouseEvent(eventName, { bubbles: true, cancelable: true, view: window }));
  });
}

function selectFromCustomCombobox(el, field, value) {
  const candidates = expandCandidateValues(field, value);
  if (!candidates.length) return false;

  clickLikeUser(el);

  const ariaControls = el.getAttribute("aria-controls");
  const scoped = ariaControls ? document.getElementById(ariaControls) : null;
  const optionSelector = "[role='option'], [data-value], li";

  const nodes = (scoped || document)
    ? Array.from((scoped || document).querySelectorAll(optionSelector)).filter((node) => isVisible(node) && normalize(node.textContent).length > 0)
    : [];

  const matched = chooseMatchingOption(nodes, candidates);
  if (!matched) return false;

  clickLikeUser(matched);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function isCustomCombobox(el) {
  return el.getAttribute("role") === "combobox" && el.tagName !== "SELECT";
}

function isSelectPlaceholder(el) {
  if (!(el instanceof HTMLSelectElement)) return false;
  const selectedIndex = el.selectedIndex;
  const selected = selectedIndex >= 0 ? el.options[selectedIndex] : null;
  const value = normalize(toHalfWidth(el.value || ""));
  const text = normalize(toHalfWidth(selected?.textContent || ""));
  const rawValue = toHalfWidth(el.value || "").trim();
  const rawText = toHalfWidth(selected?.textContent || "").trim();

  if (!value && !text) return true;
  if (selected?.disabled && !value) return true;
  if (selectedIndex === 0 && !value) return true;

  const placeholderTokens = [
    "-",
    "--",
    "---",
    "0",
    "選択",
    "選択してください",
    "未選択",
    "未設定",
    "choose",
    "select"
  ];

  if (placeholderTokens.some((token) => value === token || text === token)) return true;

  if (
    /選択|choose|select|未選択|未設定/.test(rawValue) ||
    /選択|choose|select|未選択|未設定/.test(rawText)
  ) {
    return true;
  }

  if (/^[\-ー－−▼▽]+$/.test(rawValue || rawText)) return true;

  // Some DOB dropdowns keep placeholder-like labels such as "月" or "日".
  if (selectedIndex === 0 && /^(年|月|日)$/.test(rawValue || rawText)) return true;

  return false;
}

function hasExistingValue(el) {
  if (el.tagName === "SELECT") return !isSelectPlaceholder(el);
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return el.value.trim() !== "";
  const text = normalize(el.textContent);
  return text !== "";
}

function setFieldValue(el, field, value, options = {}) {
  const { overwrite = true } = options;
  if (value == null || value === "") return false;
  if (!overwrite && hasExistingValue(el)) return false;

  if (el.tagName === "SELECT") {
    const option = chooseMatchingOption(Array.from(el.options), expandCandidateValues(field, value));
    if (!option) return false;
    el.value = option.value;
  } else if (isCustomCombobox(el)) {
    return selectFromCustomCombobox(el, field, value);
  } else if (el.type === "radio") {
    return setRadioValue(el, field, value, { overwrite });
  } else if (el.type === "checkbox") {
    return false;
  } else {
    el.focus();
    el.value = String(value);
  }

  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

function isFillable(el) {
  if (!(el instanceof HTMLElement)) return false;
  if (!isVisible(el)) return false;
  if (el.matches("[disabled], [readonly], [type='hidden']")) return false;
  if (el.getAttribute("aria-hidden") === "true") return false;
  return el.matches("input, textarea, select, [role='combobox']");
}

function buildLineGroups(candidates, tolerance = 24) {
  const positioned = candidates
    .map((candidate) => ({ candidate, rect: candidate.el.getBoundingClientRect() }))
    .sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left);

  const rows = [];
  for (const item of positioned) {
    const last = rows[rows.length - 1];
    if (!last || Math.abs(item.rect.top - last.top) > tolerance) {
      rows.push({ top: item.rect.top, items: [item] });
      continue;
    }
    last.items.push(item);
  }

  return rows.map((row) => row.items.sort((a, b) => a.rect.left - b.rect.left));
}

function findCommonAncestor(a, b) {
  const ancestors = new Set();
  let node = a;
  while (node) {
    ancestors.add(node);
    node = node.parentElement;
  }

  node = b;
  while (node) {
    if (ancestors.has(node)) return node;
    node = node.parentElement;
  }

  return null;
}

function isLikelySplitEmailPair(left, right) {
  const gap = right.rect.left - left.rect.right;
  if (gap < -10 || gap > 240) return false;

  const hintMeta = `${left.candidate.meta} ${right.candidate.meta}`.toLowerCase();
  if (/(local|domain|前半|後半|ドメイン|ユーザー|アカウント)/.test(hintMeta)) return true;

  const common = findCommonAncestor(left.candidate.el, right.candidate.el);
  const rawText = common?.textContent || "";
  if (/@/.test(rawText)) return true;

  const leftMax = Number(left.candidate.el.maxLength);
  const rightMax = Number(right.candidate.el.maxLength);
  return (
    (Number.isFinite(leftMax) && leftMax > 0 && leftMax <= 80) ||
    (Number.isFinite(rightMax) && rightMax > 0 && rightMax <= 255)
  );
}

function fillSplitEmailFields(candidates, profile, overwrite, handledElements) {
  if (!profile.email) return;

  const [localPart, domainPart] = splitEmailAddress(profile.email);
  if (!localPart || !domainPart) return;

  const emailCandidates = candidates.filter((x) => x.field === "email" && !handledElements.has(x.el));
  const rows = buildLineGroups(emailCandidates);

  for (const row of rows) {
    if (row.length < 2) continue;
    for (let i = 0; i < row.length - 1; i += 1) {
      const left = row[i];
      const right = row[i + 1];
      if (handledElements.has(left.candidate.el) || handledElements.has(right.candidate.el)) continue;
      if (!isLikelySplitEmailPair(left, right)) continue;

      const filledLeft = setFieldValue(left.candidate.el, "email", localPart, { overwrite });
      const filledRight = setFieldValue(right.candidate.el, "email", domainPart, { overwrite });
      if (filledLeft || filledRight) {
        handledElements.add(left.candidate.el);
        handledElements.add(right.candidate.el);
        i += 1;
      }
    }
  }
}

function fillSplitPhoneFields(candidates, profile, overwrite, handledElements) {
  if (!profile.phone) return;

  const phoneCandidates = candidates.filter((x) => x.field === "phone" && !handledElements.has(x.el));
  const rows = buildLineGroups(phoneCandidates);

  for (const row of rows) {
    if (row.length < 2) continue;

    const items = row.filter((x) => x.candidate.el.tagName !== "SELECT");
    if (items.length < 2) continue;

    const fields = items.map((x) => x.candidate.el);
    const explicitLengths = fields.map((el) => getExplicitSegmentLength(el));
    const common = findCommonAncestor(fields[0], fields[fields.length - 1]);
    const rowHint = common?.textContent || "";
    const hasSplitHint =
      fields.length >= 3 ||
      explicitLengths.some((len) => len > 0) ||
      /[-－ー]/.test(rowHint) ||
      /(市外局番|下4桁|上4桁|前半|後半|3桁|4桁|電話番号1|電話番号2|電話番号3)/.test(rowHint);
    if (!hasSplitHint) continue;

    const segments = splitPhoneDigits(profile.phone, fields.length, explicitLengths);

    let changed = false;
    for (let i = 0; i < fields.length; i += 1) {
      if (!segments[i]) continue;
      if (setFieldValue(fields[i], "phone", segments[i], { overwrite })) changed = true;
    }

    if (changed) {
      fields.forEach((el) => handledElements.add(el));
    }
  }
}

function fillSplitPostalFields(candidates, profile, overwrite, handledElements) {
  if (!profile.postalCode) return;

  const postalCandidates = candidates.filter((x) => x.field === "postalCode" && !handledElements.has(x.el));
  const rows = buildLineGroups(postalCandidates);

  for (const row of rows) {
    if (row.length < 2) continue;
    const [a, b] = splitPostalDigits(profile.postalCode);
    if (!a || !b) continue;

    const first = row[0].candidate.el;
    const second = row[1].candidate.el;
    const firstLen = getExplicitSegmentLength(first);
    const secondLen = getExplicitSegmentLength(second);
    const common = findCommonAncestor(first, second);
    const rowHint = common?.textContent || "";
    const hasSplitHint =
      (firstLen === 3 && secondLen === 4) || /[-－ー]/.test(rowHint) || /(前半|後半|3桁|4桁)/.test(rowHint);
    if (!hasSplitHint) continue;

    const changedA = setFieldValue(first, "postalCode", a, { overwrite });
    const changedB = setFieldValue(second, "postalCode", b, { overwrite });
    if (changedA || changedB) {
      handledElements.add(first);
      handledElements.add(second);
    }
  }
}

function fillSplitBirthDateFields(candidates, profile, overwrite, handledElements) {
  const parsed = parseBirthDate(profile.birthDate);
  if (!parsed) return;

  const birthCandidates = candidates.filter((x) => x.field === "birthDate" && !handledElements.has(x.el));
  const rows = buildLineGroups(birthCandidates);

  for (const row of rows) {
    if (row.length < 2) continue;

    const rowCandidates = row.map((x) => x.candidate);
    const byPart = { year: [], month: [], day: [] };
    const unknown = [];

    for (const candidate of rowCandidates) {
      const hint = detectBirthPartHint(candidate);
      if (hint) {
        byPart[hint].push(candidate);
      } else {
        unknown.push(candidate);
      }
    }

    if (!byPart.year.length && !byPart.month.length && !byPart.day.length && rowCandidates.length < 3) {
      continue;
    }

    let changed = false;
    for (const part of ["year", "month", "day"]) {
      for (const candidate of byPart[part]) {
        const values = birthPartValues(part, parsed);
        const ok = values.some((value) => value && setFieldValue(candidate.el, "birthDate", value, { overwrite }));
        if (ok) {
          handledElements.add(candidate.el);
          changed = true;
        }
      }
    }

    const partOrder = ["year", "month", "day"];
    const missingParts = partOrder.filter((part) => byPart[part].length === 0);
    for (let i = 0; i < unknown.length && i < missingParts.length; i += 1) {
      const part = missingParts[i];
      const values = birthPartValues(part, parsed);
      const ok = values.some((value) => value && setFieldValue(unknown[i].el, "birthDate", value, { overwrite }));
      if (ok) {
        handledElements.add(unknown[i].el);
        changed = true;
      }
    }

    if (changed) {
      for (const candidate of rowCandidates) {
        if (hasExistingValue(candidate.el)) handledElements.add(candidate.el);
      }
    }
  }
}

function collectBirthCandidates() {
  const elements = Array.from(document.querySelectorAll("input, select, [role='combobox']")).filter(isFillable);
  return elements
    .map((el) => {
      const meta = getTextMeta(el);
      const rawHint = getRawHintText(el);
      const field = matchNonNameField(meta, (el.type || "").toLowerCase());
      return { el, meta, rawHint, field };
    })
    .filter((candidate) => candidate.field === "birthDate");
}

function sleep(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

async function retrySplitBirthDateFields(profile, overwrite, handledElements) {
  const parsed = parseBirthDate(profile.birthDate);
  if (!parsed) return;

  const retryDelaysMs = [150, 300, 450];
  for (const delayMs of retryDelaysMs) {
    await sleep(delayMs);
    const birthCandidates = collectBirthCandidates();
    if (!birthCandidates.length) continue;
    fillSplitBirthDateFields(birthCandidates, profile, overwrite, handledElements);
  }
}

function fillGroupedFields(candidates, profile, overwrite, handledElements) {
  fillSplitBirthDateFields(candidates, profile, overwrite, handledElements);
  fillSplitEmailFields(candidates, profile, overwrite, handledElements);
  fillSplitPostalFields(candidates, profile, overwrite, handledElements);
  fillSplitPhoneFields(candidates, profile, overwrite, handledElements);
}

async function getSettings() {
  const stored = await storageGet([STORAGE_KEY]);
  return stored[STORAGE_KEY] || { enabled: true, profile: {} };
}

function currentDomainKey() {
  return String(location.hostname || "").toLowerCase();
}

async function getOverlayDomainStateMap() {
  const stored = await storageGet([OVERLAY_DOMAIN_STATE_KEY]);
  return stored[OVERLAY_DOMAIN_STATE_KEY] || {};
}

async function getOverlayStateForCurrentDomain() {
  const map = await getOverlayDomainStateMap();
  return map[currentDomainKey()] || { visible: false };
}

async function updateOverlayStateForCurrentDomain(patch) {
  const domain = currentDomainKey();
  if (!domain) return;
  const map = await getOverlayDomainStateMap();
  const current = map[domain] || {};
  map[domain] = { ...current, ...patch };
  await storageSet({ [OVERLAY_DOMAIN_STATE_KEY]: map });
}

function joinNonEmpty(parts, separator = " ") {
  return parts
    .map((x) => String(x || "").trim())
    .filter(Boolean)
    .join(separator);
}

function buildProfileSections(profile = {}) {
  return [
    {
      title: "基本情報",
      items: [
        { label: "氏名(漢字)", value: joinNonEmpty([profile.lastNameKanji, profile.firstNameKanji]) },
        { label: "氏名(フリガナ)", value: joinNonEmpty([profile.lastNameKana, profile.firstNameKana]) },
        { label: "氏名(English)", value: joinNonEmpty([profile.lastNameEnglish, profile.firstNameEnglish]) },
        { label: "希望名", value: profile.preferredName },
        { label: "メール", value: profile.email },
        { label: "電話番号", value: profile.phone },
        { label: "生年月日", value: profile.birthDate },
        { label: "性別", value: profile.gender }
      ]
    },
    {
      title: "住所",
      items: [
        { label: "郵便番号", value: formatPostalForSingleField(profile.postalCode) || profile.postalCode },
        { label: "都道府県", value: profile.prefecture },
        { label: "市区町村", value: profile.city },
        { label: "住所", value: profile.addressLine1 },
        { label: "建物名・部屋番号", value: profile.addressLine2 }
      ]
    },
    {
      title: "学歴",
      items: [
        { label: "学校区分", value: EDUCATION_TYPE_LABELS[profile.educationType] || profile.educationType },
        { label: "大学", value: profile.university },
        { label: "学校名頭文字", value: profile.universityKanaInitial },
        { label: "学校所在地", value: profile.universityPrefecture },
        { label: "学部/専攻", value: profile.faculty },
        { label: "卒業年", value: profile.graduationYear }
      ]
    },
    {
      title: "職歴・リンク",
      items: [
        { label: "勤務先", value: profile.company },
        { label: "LinkedIn", value: profile.linkedIn },
        { label: "GitHub", value: profile.github },
        { label: "Portfolio", value: profile.portfolio },
        { label: "自己PR", value: profile.note }
      ]
    }
  ];
}

async function copyTextToClipboard(text) {
  const payload = String(text || "");
  if (!payload) return false;

  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(payload);
      return true;
    }
  } catch (_err) {
    // Fallback below.
  }

  const ta = document.createElement("textarea");
  ta.value = payload;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  ta.style.pointerEvents = "none";
  document.body.appendChild(ta);
  ta.select();
  const ok = document.execCommand("copy");
  document.body.removeChild(ta);
  return ok;
}

function setOverlayStatus(message) {
  if (!overlayRefs?.status) return;
  overlayRefs.status.textContent = message;
  window.clearTimeout(overlayRefs.statusTimer);
  overlayRefs.statusTimer = window.setTimeout(() => {
    if (overlayRefs?.status) overlayRefs.status.textContent = "";
  }, 2200);
}

function setOverlayOpen(open) {
  if (!overlayRefs?.root) return;
  overlayRefs.root.classList.toggle("is-open", open);
}

async function setLauncherVisible(visible, options = {}) {
  const { persist = false } = options;
  if (!overlayRefs?.root) return;
  overlayRefs.root.classList.toggle("launcher-visible", visible);
  if (!visible) {
    setOverlayOpen(false);
  }
  if (persist) {
    await updateOverlayStateForCurrentDomain({ visible });
  }
}

function clampLauncherTop(topPx) {
  const minTop = 12;
  const maxTop = Math.max(minTop, window.innerHeight - 72);
  return Math.max(minTop, Math.min(maxTop, Math.round(topPx)));
}

function applyLauncherTop() {
  if (!overlayRefs?.launcherWrap) return;
  launcherTopPx = clampLauncherTop(launcherTopPx);
  overlayRefs.launcherWrap.style.top = `${launcherTopPx}px`;
}

function createProfileCopyButton(item) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "mg-copy";

  const label = document.createElement("span");
  label.className = "mg-copy-label";
  label.textContent = item.label;

  const value = document.createElement("span");
  value.className = "mg-copy-value";
  value.textContent = item.value ? String(item.value) : "未設定";

  button.append(label, value);

  if (!item.value) {
    button.disabled = true;
    button.classList.add("is-empty");
    return button;
  }

  button.addEventListener("click", async () => {
    const ok = await copyTextToClipboard(item.value);
    setOverlayStatus(ok ? `${item.label} をコピーしました` : "コピーに失敗しました");
  });

  return button;
}

function renderOverlayProfile(profile = {}) {
  if (!overlayRefs?.sections) return;
  overlayRefs.sections.innerHTML = "";

  for (const section of buildProfileSections(profile)) {
    const sectionEl = document.createElement("section");
    sectionEl.className = "mg-section";

    const title = document.createElement("h3");
    title.className = "mg-section-title";
    title.textContent = section.title;
    sectionEl.appendChild(title);

    const grid = document.createElement("div");
    grid.className = "mg-grid";
    for (const item of section.items) {
      grid.appendChild(createProfileCopyButton(item));
    }
    sectionEl.appendChild(grid);
    overlayRefs.sections.appendChild(sectionEl);
  }
}

function ensureInPageOverlay() {
  if (window !== window.top || !document.body) return null;
  if (overlayRefs) return overlayRefs;

  let host = document.getElementById(OVERLAY_HOST_ID);
  if (!host) {
    host = document.createElement("div");
    host.id = OVERLAY_HOST_ID;
    document.body.appendChild(host);
  }

  const shadow = host.shadowRoot || host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      .mg-root { position: fixed; inset: 0; pointer-events: none; z-index: 2147483646; font-family: "Hiragino Kaku Gothic ProN","Yu Gothic",sans-serif; }
      .mg-panel { pointer-events: auto; position: fixed; top: 0; right: 0; width: min(380px, calc(100vw - 16px)); height: 100vh; background: #f7fafc; border-left: 1px solid #d6e2ee; box-shadow: -12px 0 24px rgba(15, 32, 50, 0.16); transform: translateX(calc(100% + 8px)); transition: transform .2s ease; display: flex; flex-direction: column; }
      .mg-root.is-open .mg-panel { transform: translateX(0); }
      .mg-launcher-wrap { display: none; pointer-events: auto; position: fixed; right: 8px; width: 56px; height: 56px; }
      .mg-root.launcher-visible .mg-launcher-wrap { display: block; }
      .mg-root.is-open .mg-launcher-wrap { opacity: 0; transform: translateX(8px); pointer-events: none; transition: opacity .15s ease, transform .15s ease; }
      .mg-launcher { width: 56px; height: 56px; border: none; border-radius: 14px; background: #0b6fd5; color: #fff; font-size: 30px; font-weight: 800; line-height: 1; cursor: grab; box-shadow: 0 10px 22px rgba(5, 70, 138, 0.34); }
      .mg-launcher:active { cursor: grabbing; }
      .mg-launcher-hide { position: absolute; top: -8px; left: -8px; width: 22px; height: 22px; border: none; border-radius: 999px; background: #1f2c3a; color: #fff; font-size: 13px; font-weight: 700; cursor: pointer; opacity: 0; transform: scale(.9); transition: opacity .12s ease, transform .12s ease; }
      .mg-launcher-wrap:hover .mg-launcher-hide { opacity: 1; transform: scale(1); }
      .mg-header { display: flex; align-items: center; justify-content: space-between; padding: 14px 14px 10px; border-bottom: 1px solid #dbe6f1; background: #fff; }
      .mg-title { margin: 0; font-size: 20px; font-weight: 800; color: #1e2f46; }
      .mg-header-actions { display: flex; gap: 8px; }
      .mg-icon-btn { border: 1px solid #c9d7e7; background: #fff; border-radius: 8px; width: 30px; height: 30px; cursor: pointer; color: #24425f; font-weight: 700; }
      .mg-actions { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; padding: 12px 14px 0; }
      .mg-btn { border: none; border-radius: 10px; padding: 10px 12px; cursor: pointer; font-weight: 700; color: #fff; background: #0b6fd5; }
      .mg-btn.secondary { background: #2a3c52; }
      .mg-help { margin: 10px 14px 0; color: #4a5d74; font-size: 13px; }
      .mg-status { min-height: 1.4em; margin: 6px 14px 0; color: #0b6fd5; font-size: 12px; font-weight: 700; }
      .mg-sections { overflow: auto; padding: 12px 14px 16px; display: grid; gap: 12px; }
      .mg-section { background: #fff; border: 1px solid #d9e4ef; border-radius: 12px; padding: 10px; }
      .mg-section-title { margin: 2px 2px 10px; font-size: 14px; color: #2a3f57; }
      .mg-grid { display: grid; gap: 8px; }
      .mg-copy { text-align: left; border: 1px solid #d2dfec; border-radius: 10px; background: #fefefe; padding: 8px 10px; cursor: pointer; display: grid; gap: 4px; }
      .mg-copy:hover { border-color: #87afd9; background: #f5faff; }
      .mg-copy:disabled, .mg-copy.is-empty { cursor: default; opacity: 0.7; background: #f7f9fc; }
      .mg-copy-label { font-size: 12px; color: #4a6079; font-weight: 700; }
      .mg-copy-value { font-size: 13px; color: #1c3149; white-space: pre-wrap; word-break: break-word; }
    </style>
    <div class="mg-root">
      <div class="mg-launcher-wrap" data-role="launcher-wrap">
        <button class="mg-launcher" type="button" title="Open Magulify">M</button>
        <button class="mg-launcher-hide" type="button" data-role="hide-launcher" title="Hide">×</button>
      </div>
      <aside class="mg-panel" aria-label="Magulify Profile Panel">
        <header class="mg-header">
          <h2 class="mg-title">Magulify Profile</h2>
          <div class="mg-header-actions">
            <button class="mg-icon-btn" type="button" data-role="close" title="Close">×</button>
          </div>
        </header>
        <div class="mg-actions">
          <button class="mg-btn" type="button" data-role="autofill">Autofill Now</button>
          <button class="mg-btn secondary" type="button" data-role="refresh">Refresh</button>
          <button class="mg-btn secondary" type="button" data-role="edit">Edit</button>
        </div>
        <p class="mg-help">Click any block below to copy it.</p>
        <p class="mg-status" data-role="status"></p>
        <div class="mg-sections" data-role="sections"></div>
      </aside>
    </div>
  `;

  const root = shadow.querySelector(".mg-root");
  const launcherWrap = shadow.querySelector("[data-role='launcher-wrap']");
  const launcher = shadow.querySelector(".mg-launcher");
  const hideLauncherBtn = shadow.querySelector("[data-role='hide-launcher']");
  const closeBtn = shadow.querySelector("[data-role='close']");
  const refreshBtn = shadow.querySelector("[data-role='refresh']");
  const autofillBtn = shadow.querySelector("[data-role='autofill']");
  const editBtn = shadow.querySelector("[data-role='edit']");
  const status = shadow.querySelector("[data-role='status']");
  const sections = shadow.querySelector("[data-role='sections']");

  let suppressLauncherClick = false;
  launcher.addEventListener("click", (event) => {
    if (suppressLauncherClick) {
      suppressLauncherClick = false;
      event.preventDefault();
      return;
    }
    setOverlayOpen(true);
  });
  hideLauncherBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    setLauncherVisible(false, { persist: true }).catch(() => {});
  });
  closeBtn.addEventListener("click", () => setOverlayOpen(false));

  refreshBtn.addEventListener("click", async () => {
    const settings = await getSettings();
    renderOverlayProfile(settings.profile || {});
    setOverlayStatus("プロフィールを更新しました");
  });

  autofillBtn.addEventListener("click", async () => {
    const result = await autofill({ overwrite: true });
    setOverlayStatus(`${result.filled || 0} 項目を入力しました`);
  });

  editBtn.addEventListener("click", async () => {
    try {
      await openOptionsPage();
      setOverlayStatus("設定ページを開きました");
    } catch (_err) {
      setOverlayStatus("設定ページを開けませんでした");
    }
  });

  let dragging = false;
  let dragOffset = 0;
  let dragStartY = 0;

  launcher.addEventListener("pointerdown", (event) => {
    dragging = true;
    suppressLauncherClick = false;
    dragStartY = event.clientY;
    dragOffset = event.clientY - launcherTopPx;
    launcher.setPointerCapture?.(event.pointerId);
  });

  launcher.addEventListener("pointermove", (event) => {
    if (!dragging) return;
    if (Math.abs(event.clientY - dragStartY) > 4) suppressLauncherClick = true;
    launcherTopPx = clampLauncherTop(event.clientY - dragOffset);
    applyLauncherTop();
  });

  const endDrag = (event) => {
    if (!dragging) return;
    dragging = false;
    launcher.releasePointerCapture?.(event.pointerId);
    updateOverlayStateForCurrentDomain({ top: launcherTopPx }).catch(() => {});
  };

  launcher.addEventListener("pointerup", endDrag);
  launcher.addEventListener("pointercancel", endDrag);
  window.addEventListener("resize", applyLauncherTop);

  overlayRefs = {
    host,
    shadow,
    root,
    launcherWrap,
    launcher,
    hideLauncherBtn,
    closeBtn,
    refreshBtn,
    autofillBtn,
    editBtn,
    status,
    sections,
    statusTimer: null,
    resizeHandler: applyLauncherTop
  };
  applyLauncherTop();

  return overlayRefs;
}

async function refreshInPageOverlay() {
  const refs = ensureInPageOverlay();
  if (!refs) return;
  const settings = await getSettings();
  renderOverlayProfile(settings.profile || {});
}

function bindInPageOverlayStorageListener() {
  if (storageListenerBound) return;
  extensionApi.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "sync" && areaName !== "local") return;
    const changed = changes[STORAGE_KEY];
    if (!changed || !overlayRefs) return;
    renderOverlayProfile(changed.newValue?.profile || {});
  });
  storageListenerBound = true;
}

async function initInPageOverlay(options = {}) {
  const { showLauncher = false, persist = false } = options;
  if (window !== window.top || !document.body) return;
  ensureInPageOverlay();
  bindInPageOverlayStorageListener();
  await refreshInPageOverlay();
  await setLauncherVisible(showLauncher, { persist });
  setOverlayOpen(false);
}

async function autofill(options = {}) {
  const { overwrite = true } = options;
  const settings = await getSettings();
  if (!settings.enabled) {
    return { filled: 0, reason: "disabled" };
  }

  const profile = settings.profile || {};
  const inputs = Array.from(document.querySelectorAll("input, textarea, select, [role='combobox']")).filter(isFillable);

  const candidates = inputs.map((el) => {
    const meta = getTextMeta(el);
    const rawHint = getRawHintText(el);
    return { el, meta, rawHint, field: null, kanaTarget: null, namePart: null, scriptHint: null };
  });

  assignNameFields(candidates);

  for (const candidate of candidates) {
    if (candidate.field !== null && candidate.field !== undefined) continue;
    candidate.field = matchNonNameField(candidate.meta, (candidate.el.type || "").toLowerCase());
  }

  const handledElements = new Set();
  fillGroupedFields(candidates, profile, overwrite, handledElements);
  await retrySplitBirthDateFields(profile, overwrite, handledElements);

  let filled = 0;
  for (const candidate of candidates) {
    const { el, field } = candidate;
    if (handledElements.has(el)) continue;
    if (!field) continue;
    const value = resolveAutofillValue(candidate, profile);
    if (setFieldValue(el, field, value, { overwrite })) filled += 1;
  }

  return { filled };
}

function debounce(fn, waitMs) {
  let timeoutId = null;
  return (...args) => {
    window.clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => fn(...args), waitMs);
  };
}

function startAutoRun() {
  const trigger = debounce(() => {
    autofill({ overwrite: false }).catch(() => {});
  }, AUTO_RUN_DEBOUNCE_MS);

  trigger();

  const observer = new MutationObserver(() => trigger());
  observer.observe(document.documentElement, { childList: true, subtree: true });
  window.setTimeout(() => observer.disconnect(), AUTO_RUN_OBSERVE_MS);
}

async function maybeShowLauncherFromDomainState() {
  if (window !== window.top) return;
  const state = await getOverlayStateForCurrentDomain();
  if (!state?.visible) return;
  if (Number.isFinite(Number(state.top))) {
    launcherTopPx = clampLauncherTop(Number(state.top));
  }
  await initInPageOverlay({ showLauncher: true, persist: false });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startAutoRun, { once: true });
  document.addEventListener(
    "DOMContentLoaded",
    () => {
      maybeShowLauncherFromDomainState().catch(() => {});
    },
    { once: true }
  );
} else {
  startAutoRun();
  maybeShowLauncherFromDomainState().catch(() => {});
}

extensionApi.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "MAGULIFY_SHOW_LAUNCHER") {
    getOverlayStateForCurrentDomain()
      .then((state) => {
        if (Number.isFinite(Number(state?.top))) {
          launcherTopPx = clampLauncherTop(Number(state.top));
        }
        return initInPageOverlay({ showLauncher: true, persist: true });
      })
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg?.type !== "AUTOFILL_NOW") return;

  autofill({ overwrite: true })
    .then((result) => sendResponse({ ok: true, result }))
    .catch((err) => sendResponse({ ok: false, error: String(err) }));

  return true;
});
