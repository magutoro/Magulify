importScripts("extension-api-compat.js");

const { extensionApi, storageGet, storageSet, queryTabs, sendMessageIgnoringErrors } =
  globalThis.ExtensionApiCompat || {};

if (!extensionApi || !storageGet || !storageSet || !queryTabs || !sendMessageIgnoringErrors) {
  throw new Error("Extension API compatibility helpers are not available.");
}

const DEFAULT_PROFILE = {
  lastNameKanji: "",
  firstNameKanji: "",
  lastNameKana: "",
  firstNameKana: "",
  lastNameEnglish: "",
  firstNameEnglish: "",
  preferredName: "",
  email: "",
  phone: "",
  gender: "",
  password: "",
  postalCode: "",
  prefecture: "",
  city: "",
  addressLine1: "",
  addressLine2: "",
  birthDate: "",
  university: "",
  educationType: "",
  universityKanaInitial: "",
  universityPrefecture: "",
  faculty: "",
  graduationYear: "",
  company: "",
  linkedIn: "",
  github: "",
  portfolio: "",
  note: ""
};

const DEFAULT_SETTINGS = {
  enabled: true,
  profile: DEFAULT_PROFILE
};

async function ensureDefaults() {
  const stored = await storageGet(["settings"]);
  if (!stored.settings) {
    await storageSet({ settings: DEFAULT_SETTINGS });
    return;
  }

  const merged = {
    ...DEFAULT_SETTINGS,
    ...stored.settings,
    profile: {
      ...DEFAULT_PROFILE,
      ...(stored.settings.profile || {})
    }
  };

  await storageSet({ settings: merged });
}

extensionApi.runtime.onInstalled.addListener(() => {
  ensureDefaults().catch((err) => console.error("Failed to initialize settings", err));
});

extensionApi.commands.onCommand.addListener(async (command) => {
  if (command !== "run-autofill") return;

  const [{ id: tabId } = {}] = await queryTabs({ active: true, currentWindow: true });
  if (!tabId) return;

  sendMessageIgnoringErrors(tabId, { type: "AUTOFILL_NOW" });
});

extensionApi.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "GET_DEFAULTS") return;

  sendResponse({
    defaults: DEFAULT_SETTINGS
  });
});
