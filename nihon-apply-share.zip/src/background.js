const DEFAULT_PROFILE = {
  lastNameKanji: "",
  firstNameKanji: "",
  lastNameKana: "",
  firstNameKana: "",
  lastNameEnglish: "",
  firstNameEnglish: "",
  preferredName: "",
  email: "",
  phone: "",
  gender: "",
  password: "",
  postalCode: "",
  prefecture: "",
  city: "",
  addressLine1: "",
  addressLine2: "",
  birthDate: "",
  university: "",
  educationType: "",
  universityKanaInitial: "",
  universityPrefecture: "",
  faculty: "",
  graduationYear: "",
  company: "",
  linkedIn: "",
  github: "",
  portfolio: "",
  note: ""
};

const DEFAULT_SETTINGS = {
  enabled: true,
  profile: DEFAULT_PROFILE
};

async function ensureDefaults() {
  const stored = await chrome.storage.sync.get(["settings"]);
  if (!stored.settings) {
    await chrome.storage.sync.set({ settings: DEFAULT_SETTINGS });
    return;
  }

  const merged = {
    ...DEFAULT_SETTINGS,
    ...stored.settings,
    profile: {
      ...DEFAULT_PROFILE,
      ...(stored.settings.profile || {})
    }
  };

  await chrome.storage.sync.set({ settings: merged });
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaults().catch((err) => console.error("Failed to initialize settings", err));
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "run-autofill") return;

  const [{ id: tabId }] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabId) return;

  chrome.tabs.sendMessage(tabId, { type: "AUTOFILL_NOW" });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== "GET_DEFAULTS") return;

  sendResponse({
    defaults: DEFAULT_SETTINGS
  });
});
