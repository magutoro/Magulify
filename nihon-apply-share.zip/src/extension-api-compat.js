(() => {
  if (globalThis.ExtensionApiCompat) {
    return;
  }

  const extensionApi = globalThis.browser ?? globalThis.chrome;
  if (!extensionApi) {
    throw new Error("WebExtension API is not available.");
  }

  const storageArea = extensionApi.storage?.sync ?? extensionApi.storage?.local;
  if (!storageArea) {
    throw new Error("WebExtension storage API is not available.");
  }

  function toApiError(err) {
    if (!err) return new Error("Unknown WebExtension API error.");
    return err instanceof Error ? err : new Error(String(err.message || err));
  }

  async function storageGet(keys) {
    if (globalThis.browser?.storage) {
      return storageArea.get(keys);
    }

    return new Promise((resolve, reject) => {
      storageArea.get(keys, (result) => {
        const err = globalThis.chrome?.runtime?.lastError;
        if (err) {
          reject(toApiError(err));
          return;
        }
        resolve(result);
      });
    });
  }

  async function storageSet(values) {
    if (globalThis.browser?.storage) {
      return storageArea.set(values);
    }

    return new Promise((resolve, reject) => {
      storageArea.set(values, () => {
        const err = globalThis.chrome?.runtime?.lastError;
        if (err) {
          reject(toApiError(err));
          return;
        }
        resolve();
      });
    });
  }

  async function queryTabs(queryInfo) {
    if (globalThis.browser?.tabs) {
      return extensionApi.tabs.query(queryInfo);
    }

    return new Promise((resolve, reject) => {
      extensionApi.tabs.query(queryInfo, (tabs) => {
        const err = globalThis.chrome?.runtime?.lastError;
        if (err) {
          reject(toApiError(err));
          return;
        }
        resolve(tabs || []);
      });
    });
  }

  async function sendMessage(tabId, message) {
    if (globalThis.browser?.tabs) {
      return extensionApi.tabs.sendMessage(tabId, message);
    }

    return new Promise((resolve, reject) => {
      extensionApi.tabs.sendMessage(tabId, message, (response) => {
        const err = globalThis.chrome?.runtime?.lastError;
        if (err) {
          reject(toApiError(err));
          return;
        }
        resolve(response);
      });
    });
  }

  function sendMessageIgnoringErrors(tabId, message) {
    if (globalThis.browser?.tabs) {
      extensionApi.tabs.sendMessage(tabId, message).catch(() => {});
      return;
    }

    extensionApi.tabs.sendMessage(tabId, message, () => {
      void globalThis.chrome?.runtime?.lastError;
    });
  }

  async function openOptionsPage() {
    if (globalThis.browser?.runtime) {
      return extensionApi.runtime.openOptionsPage();
    }

    return new Promise((resolve, reject) => {
      extensionApi.runtime.openOptionsPage(() => {
        const err = globalThis.chrome?.runtime?.lastError;
        if (err) {
          reject(toApiError(err));
          return;
        }
        resolve();
      });
    });
  }

  globalThis.ExtensionApiCompat = {
    extensionApi,
    storageGet,
    storageSet,
    queryTabs,
    sendMessage,
    sendMessageIgnoringErrors,
    openOptionsPage
  };
})();
